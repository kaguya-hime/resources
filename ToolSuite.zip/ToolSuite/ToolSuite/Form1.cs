﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Outlook;

namespace ToolSuite
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public bool NotifySendFlag = false;
        public string NotifyTemplete = "";
        public string NotifyTitleTemplete = "";
        public string ResultTemplete = "";
        public string ResultTitleTemplete = "";
        public string ToAddress = "";
        private string NotifyPath = "notify.txt";
        private string ResultPath = "result.txt";
        private string ToAddressPath = "to.txt";

        private void Form1_Load(object sender, EventArgs e)
        {
            GetNowTime();
            ReloadTempletes();
        }

        private void ReloadTempletes()
        {
            NotifyTemplete = "";
            ResultTemplete = "";
            string[] NotifyLines = File.ReadAllLines(NotifyPath);
            foreach(string temp in NotifyLines)
            {
                if (temp.Contains("subject:"))
                {
                    NotifyTitleTemplete = temp.Replace("subject:", "");
                }
                else
                {
                    NotifyTemplete += temp + "\r\n";
                }
            }
            string[] ResultLines = File.ReadAllLines(ResultPath);
            foreach(string temp in ResultLines)
            {
                if (temp.Contains("subject:"))
                {
                    ResultTitleTemplete = temp.Replace("subject:", "");
                }
                else
                {
                    ResultTemplete += temp + "\r\n";
                }
            }
            ToAddress = File.ReadAllText(ToAddressPath);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            bool bHandled = false;
            // switch case is the easy way, a hash or map would be better, 
            // but more work to get set up.
            switch (keyData)
            {
                case Keys.F5:
                    // do whatever
                    bHandled = true;
                    GetNowTime();
                    break;
                case Keys.Enter:
                    bHandled = true;
                    GenerateMsg();
                    break;
            }
            return bHandled;
        }

        private void GetNowTime()
        {
            DateTime now = DateTime.Now;
            //DateTime end = now.AddMinutes(10);
            string fmt = "yyyy/MM/dd HH:mm";
            if (!NotifySendFlag)
            {
                this.startTimeTextBox.Text = now.ToString(fmt);
            }
            this.endTimeTextBox.Text = now.ToString(fmt);
        }

        private void GenerateMsg()
        {
            GetNowTime();
            ReloadTempletes();
            this.notifyTitleTextBox.Text = this.NotifyTitleTemplete.Replace("{time_start}", this.startTimeTextBox.Text);
            this.resultTitleTextBox.Text = this.ResultTitleTemplete.Replace("{time_finish}", this.endTimeTextBox.Text);
            string NotifyMsg = this.NotifyTemplete.Replace("{time_start}", this.startTimeTextBox.Text);
            this.notifyTextBox.Text = NotifyMsg;
            string ResultMsg = this.ResultTemplete.Replace("{time_start}", this.startTimeTextBox.Text).Replace("{time_finish}", this.endTimeTextBox.Text).Replace("{objects}", GenerateObjects());
            this.resultTextBox.Text = ResultMsg;
        }

        private string GenerateObjects()
        {
            string[] objects = this.objectsTextBox.Lines;
            string result = "";
            foreach(string temp in objects)
            {
                if (temp != "")
                {
                    result += "　　・" + temp + "\r\n";
                }
            }
            return result;
        }

        private void NotifySendButton_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Outlook.Application olApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.MailItem mailItem = (Microsoft.Office.Interop.Outlook.MailItem)olApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
            mailItem.To = ToAddress;
            mailItem.Subject = this.notifyTitleTextBox.Text;
            mailItem.BodyFormat = Microsoft.Office.Interop.Outlook.OlBodyFormat.olFormatHTML;
            string content = this.notifyTextBox.Text;
            mailItem.Body = content;
            ((Microsoft.Office.Interop.Outlook._MailItem)mailItem).Send();
        }

        private void ResultSendButton_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Outlook.Application olApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.MailItem mailItem = (Microsoft.Office.Interop.Outlook.MailItem)olApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
            mailItem.To = ToAddress;
            mailItem.Subject = this.resultTitleTextBox.Text;
            mailItem.BodyFormat = Microsoft.Office.Interop.Outlook.OlBodyFormat.olFormatHTML;
            string content = this.resultTextBox.Text;
            mailItem.Body = content;
            ((Microsoft.Office.Interop.Outlook._MailItem)mailItem).Send();
        }
    }
}
