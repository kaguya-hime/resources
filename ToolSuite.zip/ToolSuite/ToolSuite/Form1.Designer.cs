﻿namespace ToolSuite
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.ResultSendButton = new System.Windows.Forms.Button();
            this.NotifySendButton = new System.Windows.Forms.Button();
            this.resultTitleTextBox = new System.Windows.Forms.TextBox();
            this.notifyTitleTextBox = new System.Windows.Forms.TextBox();
            this.resultTextBox = new System.Windows.Forms.TextBox();
            this.notifyTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.objectsTextBox = new System.Windows.Forms.TextBox();
            this.endTimeTextBox = new System.Windows.Forms.TextBox();
            this.startTimeTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(695, 479);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(689, 473);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.ResultSendButton);
            this.tabPage3.Controls.Add(this.NotifySendButton);
            this.tabPage3.Controls.Add(this.resultTitleTextBox);
            this.tabPage3.Controls.Add(this.notifyTitleTextBox);
            this.tabPage3.Controls.Add(this.resultTextBox);
            this.tabPage3.Controls.Add(this.notifyTextBox);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.endTimeTextBox);
            this.tabPage3.Controls.Add(this.startTimeTextBox);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(681, 447);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "デプロイメール";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // ResultSendButton
            // 
            this.ResultSendButton.Location = new System.Drawing.Point(8, 311);
            this.ResultSendButton.Name = "ResultSendButton";
            this.ResultSendButton.Size = new System.Drawing.Size(190, 23);
            this.ResultSendButton.TabIndex = 10;
            this.ResultSendButton.Text = "完成メールを送信";
            this.ResultSendButton.UseVisualStyleBackColor = true;
            this.ResultSendButton.Click += new System.EventHandler(this.ResultSendButton_Click);
            // 
            // NotifySendButton
            // 
            this.NotifySendButton.Location = new System.Drawing.Point(8, 282);
            this.NotifySendButton.Name = "NotifySendButton";
            this.NotifySendButton.Size = new System.Drawing.Size(190, 23);
            this.NotifySendButton.TabIndex = 9;
            this.NotifySendButton.Text = "予定メールを送信";
            this.NotifySendButton.UseVisualStyleBackColor = true;
            this.NotifySendButton.Click += new System.EventHandler(this.NotifySendButton_Click);
            // 
            // resultTitleTextBox
            // 
            this.resultTitleTextBox.Location = new System.Drawing.Point(8, 247);
            this.resultTitleTextBox.Name = "resultTitleTextBox";
            this.resultTitleTextBox.Size = new System.Drawing.Size(190, 19);
            this.resultTitleTextBox.TabIndex = 7;
            // 
            // notifyTitleTextBox
            // 
            this.notifyTitleTextBox.Location = new System.Drawing.Point(8, 221);
            this.notifyTitleTextBox.Name = "notifyTitleTextBox";
            this.notifyTitleTextBox.Size = new System.Drawing.Size(190, 19);
            this.notifyTitleTextBox.TabIndex = 5;
            // 
            // resultTextBox
            // 
            this.resultTextBox.Location = new System.Drawing.Point(205, 220);
            this.resultTextBox.MaxLength = 32767000;
            this.resultTextBox.Multiline = true;
            this.resultTextBox.Name = "resultTextBox";
            this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.resultTextBox.Size = new System.Drawing.Size(470, 206);
            this.resultTextBox.TabIndex = 8;
            // 
            // notifyTextBox
            // 
            this.notifyTextBox.Location = new System.Drawing.Point(205, 8);
            this.notifyTextBox.MaxLength = 32767000;
            this.notifyTextBox.Multiline = true;
            this.notifyTextBox.Name = "notifyTextBox";
            this.notifyTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.notifyTextBox.Size = new System.Drawing.Size(470, 206);
            this.notifyTextBox.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.objectsTextBox);
            this.groupBox1.Location = new System.Drawing.Point(8, 64);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(190, 150);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "更新対象";
            // 
            // objectsTextBox
            // 
            this.objectsTextBox.Location = new System.Drawing.Point(7, 19);
            this.objectsTextBox.Multiline = true;
            this.objectsTextBox.Name = "objectsTextBox";
            this.objectsTextBox.Size = new System.Drawing.Size(177, 125);
            this.objectsTextBox.TabIndex = 0;
            // 
            // endTimeTextBox
            // 
            this.endTimeTextBox.Location = new System.Drawing.Point(65, 35);
            this.endTimeTextBox.Name = "endTimeTextBox";
            this.endTimeTextBox.Size = new System.Drawing.Size(133, 19);
            this.endTimeTextBox.TabIndex = 3;
            // 
            // startTimeTextBox
            // 
            this.startTimeTextBox.Location = new System.Drawing.Point(65, 13);
            this.startTimeTextBox.Name = "startTimeTextBox";
            this.startTimeTextBox.Size = new System.Drawing.Size(133, 19);
            this.startTimeTextBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "完成時間";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "予定時間";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(702, 485);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ToolSuite";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox resultTextBox;
        private System.Windows.Forms.TextBox notifyTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox objectsTextBox;
        private System.Windows.Forms.TextBox endTimeTextBox;
        private System.Windows.Forms.TextBox startTimeTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox resultTitleTextBox;
        private System.Windows.Forms.TextBox notifyTitleTextBox;
        private System.Windows.Forms.Button ResultSendButton;
        private System.Windows.Forms.Button NotifySendButton;
    }
}

